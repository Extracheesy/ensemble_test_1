"""
findicators
"""

__all__ = ["findicators","vsa"]
__version__ = '0.1'
__author__ = 'ced'
