"""
featureengineering
"""

__all__ = ["fselection", "fbalance", "fprocessfeature", "fstationary","flabeling"]
__version__ = '0.1'
__author__ = 'ced'
