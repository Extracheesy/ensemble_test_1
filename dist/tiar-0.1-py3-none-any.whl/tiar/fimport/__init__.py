"""
fimport
"""

__all__ = ["fimport","synthetic","visu"]
__version__ = '0.1'
__author__ = 'ced'
