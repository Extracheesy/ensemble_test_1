"""
data preprocessing
"""

__all__ = ["fdataprep", "fprep", "fdiscretize"]
__version__ = '0.1'
__author__ = 'ced'
