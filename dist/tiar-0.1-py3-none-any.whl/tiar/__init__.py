__all__ = ["alfred"]
__version__ = '0.1'
__author__ = 'ced'
__email__ = 'foobar@fake.com'
