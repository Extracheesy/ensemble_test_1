__all__ = ["alfred"]
__version__ = '0.1'
__author__ = 'cedfactory'
__email__ = 'foobar@fake.com'